# mnetwork



## Installation

```bash
pip install mnetwork
```
